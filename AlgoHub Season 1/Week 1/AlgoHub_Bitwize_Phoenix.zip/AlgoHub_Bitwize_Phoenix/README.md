1.Abdullah Al Mamun,D-95,32
2.Anwar Hossen,D-95,21
3.Habibullah Mia,D-95,1