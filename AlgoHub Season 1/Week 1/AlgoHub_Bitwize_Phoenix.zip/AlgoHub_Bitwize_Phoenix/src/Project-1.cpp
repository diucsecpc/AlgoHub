#include<iostream>
#include<iomanip>
using namespace std;
float average(float arr[],int size) {
    float sum=0;
    for(int i=0;i<size;i++) {
        sum+=arr[i];
    }
    return sum/size;
}
float highest(float arr[],int size) {
    float Max=arr[0];
    for (int i=1;i<size;i++) {
        if(Max<arr[i]) {
            Max=arr[i];
        }
    }
    return Max;
}
float lowest(float arr[],int size) {
    float Min=arr[0];
    for(int i=1;i<size;i++) {
        if(Min>arr[i]) {
            Min=arr[i];
        }
    }
    return Min;
}
float Grade(float arr[],int i) {
    float grade;
    cout  << i+1 << ". ";
    cin >> grade;
    if(grade<0 || grade>4.00) {
        cout << "Invalid grade! Please enter a valid grade.\n";
        grade=Grade(arr,i);
    }
    return grade;
}
void update(float arr[],int size) {
    int slNo;
    float newGrade;
    cout << "Enter sl no of student : ";
    cin >> slNo;
    cout <<endl;
    cout << "The grade of this student : " << arr[slNo-1] <<endl;
    cout << "Enter new grade : ";
    cin >> newGrade;
    if(newGrade<0 || newGrade>4.00) {
        cout << "Invalid grade! Please enter a valid grade.\n";
        newGrade=Grade(arr,slNo-1);
    }
    arr[slNo-1]=newGrade;
    cout << "\n";
    cout << "Here is your updated list : " <<endl;
    for(int i=0;i<size;i++) {
        cout << i+1 << ". " << fixed << setprecision(2) << arr[i] <<endl;
    }
    int result_or_exit;
    cout << "Press 1 to show result after update & any key to not.";
    cin >> result_or_exit;
    switch (result_or_exit) {
        case 1: {
            cout << "The average of the grade list : " << fixed << setprecision(2) << average(arr,size) << endl;
            cout << "The highest of the grade list : " << fixed << setprecision(2) << highest(arr,size) << endl;
            cout << "The lowest of the grade list : " << fixed << setprecision(2) << lowest(arr,size) << endl;
            break;
        }
        default :
            break;
    }
}
int main() {
    int end=1;
    while(end) {
        int n;
        cout << "Enter no. of students : ";
        cin >> n;
        float arr[n];
        cout << "Enter grades (0<=Grade<=4.00) :\n";
        for(int i=0;i<n;i++) {
            arr[i]=Grade(arr,i);
        }
        cout << "Here is your list : " <<endl;
        for(int i=0;i<n;i++) {
            cout << i+1 << ". " << fixed << setprecision(2) << arr[i] <<endl;
        }
        int result_or_update;
        cout << "1.Show results\n2.Update\nAny Key. Exit\n";
        cin >> result_or_update;
        switch (result_or_update) {
            case 1: {
                cout << "The average of the grade list : " << fixed << setprecision(2) << average(arr,n) << endl;
                cout << "The highest of the grade list : " << fixed << setprecision(2) << highest(arr,n) << endl;
                cout << "The lowest of the grade list : " << fixed << setprecision(2) << lowest(arr,n) << endl;
                break;
            }
            case 2:
                update(arr,n);
                break;
            default :
                end=0;
                break;
        }
    }
    return 0;
}